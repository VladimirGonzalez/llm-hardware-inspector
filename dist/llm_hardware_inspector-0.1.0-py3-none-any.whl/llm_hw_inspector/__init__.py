"""
LLM Hardware Inspector
----------------------
Paquete que contiene las herramientas para la inspecci�n de hardware
y la generaci�n de sugerencias LLM.
"""
__version__ = "0.1.0"
